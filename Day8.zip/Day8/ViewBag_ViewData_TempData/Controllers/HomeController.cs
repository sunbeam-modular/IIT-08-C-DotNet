using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using ViewBag_ViewData_TempData.Models;

namespace ViewBag_ViewData_TempData.Controllers
{
    public class HomeController : Controller
    {
       

        public HomeController()
        {
            
        }

        public IActionResult Index()
        {
            string user = "priya";

            ViewData["Msg"] = "hello " + user;
            ViewData["count"] = 10;
            TempData["TempMsg"] = "hii i am from temp";
            ViewBag.Count = 20;
            //return View();
            return RedirectToAction(nameof(Print));
        }

        public IActionResult Print()
        {
            return View();
        }



    }
}
