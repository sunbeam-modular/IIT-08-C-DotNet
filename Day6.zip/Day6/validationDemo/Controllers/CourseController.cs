﻿using Microsoft.AspNetCore.Mvc;

namespace validationDemo.Controllers
{
    public class CourseController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
