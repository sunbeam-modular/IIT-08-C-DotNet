﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using validationDemo.Models;

namespace validationDemo.Controllers
{
    public class StudentController : Controller
    {

        SbContext sb = new SbContext();
        public IActionResult Index()
        {
            return View(sb.Students.Include(c => c.Course).ToList());


        }

        public IActionResult Create()
        {

            ViewBag.Courses = new SelectList(sb.Courses.ToList(), "CourseId", "CourseName");


            return View();
        }

        public IActionResult AfterCreate(Student s)
        {
            // Course c = sb.Courses.Find(id);
            sb.Students.Add(s);
            sb.SaveChanges();




            // sb.Courses.Update(c);
            return Redirect("/Student/Index");
        }

        public IActionResult Edit(int id)
        {

            Student s = sb.Students.Find(id);
            ViewBag.Courses = new SelectList(sb.Courses.Where(c => c.CourseId == s.CourseId), "CourseId", "CourseName");


            return View(sb.Students.Find(id));
        }

        public IActionResult AfterEdit(Student s)
        {
            sb.Students.Update(s);
            sb.SaveChanges();



            return Redirect("/Student/Index");

        }

        public IActionResult Delete(int id)
        {
            return View(sb.Students.Find(id));
        }

        public IActionResult AfterDelete(int id)
        {
            Student s = sb.Students.Find(id);
            sb.Students.Remove(s);
            sb.SaveChanges();
            return Redirect("/Student/Index");
        }
    }
}

