﻿using System.Security.Cryptography;

namespace LinqDemo
{
    class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int CourseId { get; set; }
    }

    class Course
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
    }

    class Program
    {
        static void Main()
        {
            // Sample students
            var students = new List<Student>
        {
            new Student { Id = 1, Name = "Alice", Address = "Mumbai", CourseId = 101 },
            new Student { Id = 2, Name = "Bob", Address = "Pune", CourseId = 102 },
            new Student { Id = 3, Name = "Charlie", Address = "Delhi", CourseId = 101 },
            new Student { Id = 4, Name = "Anita", Address = "Mumbai", CourseId = 103 }
        };

            // Sample courses
            var courses = new List<Course>
        {
            new Course { CourseId = 101, CourseName = "Math" },
            new Course { CourseId = 102, CourseName = "Science" },
            new Course { CourseId = 103, CourseName = "English" }
        };

            //// 1. Filter students by Address
            Console.WriteLine("enter the character search in Address");
            string filter = Console.ReadLine();
           var result= (from stud in students
            where stud.Address.Contains(filter)
            select stud).ToList();
            Console.WriteLine(result);
            foreach (var s1 in result)
            {
                Console.WriteLine(s1.Name);
            }

            var result1 = (from stud in students
                          where stud.Address.Contains(filter)
                          select new { stud.Id, stud.Name }
                          ).ToList();
            foreach (var info in result1)
                Console.WriteLine($"{info.Id} - {info.Name}");

            var studentCourse = from s1 in students
                                join
                                 c in courses
                                on s1.CourseId equals c.CourseId
                                select new { s1.Name, c.CourseName };

            Console.WriteLine("\nStudent & Course:");
            foreach (var sc in studentCourse)
                Console.WriteLine($"{sc.Name} - {sc.CourseName}");

            var result3 = studentCourse.Where(s => s.CourseName.Contains("C"));
            var result4 = students.Single(s => s.Id == 2);
            students.SingleOrDefault(c => c.Name=="CS");
            

            // First() – must find a match
            var firstResult = students.First(s => s.Name.StartsWith("A"));
            Console.WriteLine(firstResult);    // Output: Amit

            // FirstOrDefault() – safe version
            var safeResult = students.FirstOrDefault(s => s.Name.StartsWith("Z"));

            if (safeResult == null)
                Console.WriteLine("No student found");


        }
    }

    
}
