﻿using System.Security.Cryptography.X509Certificates;

namespace InheritanceDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person p = new Student();
            p.Accept();
            Student s1 = new Student();
            
        }
    }

    class Person
    {


        private int _age;

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

           public virtual void Accept()
        {
            Console.WriteLine("in Person");
        }



    }

    class Student:  Person
    {
        private int _rollNo;

        public int RollNo
        {
            get { return _rollNo; }
            set { _rollNo = value; }
        }

        /*private string  _name;

        public string  Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private int _age;

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }*/
        public  override void  Accept()
        {
            Console.WriteLine("in Student");
        }


    }
}
