﻿namespace ClassDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Student s1 = new Student();
            s1.setRollNo(20);
            int rollno=s1.getRollNo();*/
            /*Console.WriteLine("RollNO: "+rollno);*/
            Student student = new Student();
            student.Name = "Priya";//set called
            string name = student.Name;
            Console.WriteLine("name: "+name);

            Student s1=new Student(10, "jacky", "DKTE");
            Console.WriteLine($"Name:{s1.Name}");


        }
    }
    //by default data member/fields and methods are private
    class Student  //class <className>
    {
        private int _rollNo;  //data member
        private string _name;
        private string _course;

        //default ctor
        public Student()
        {
            _name = " ";
            _rollNo = 0;
        }

        public Student(int rollNo,string name,string cname)
        {
            this._rollNo = rollNo;
            this.Name = name;
            this._course = cname;

        }


        public  string Name
        {
            set { this._name = value; }
            get { return this._name; }
        }

        private string clgName;

        public string ClgName
        {
            get { return clgName; }
            set { clgName = value; }
        }



        //Member function
        /* public void setRollNo(int rollno)
         {
             this.rollNo = rollno;
         }
         public int getRollNo()
         {
             return this.rollNo;
         }*/
    }
}
