﻿namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Output Method:WriteLine
            //Console.WriteLine("Hello, DKTE :Welcome!");

            //we can print "+"
            //Console.WriteLine("Hello :" + "Riya");
            //placeholder
            string name = "Riya";
            string city = "Kolhapur";
            //Console.WriteLine("City:{0} Name:{1}",city,name);

            //string interpolation
            Console.WriteLine($"City:{city}  Name:{name}");
            #endregion
            #region InputMethod:ReadLine()
            string name1=Console.ReadLine();
            
            Console.WriteLine("Name:"+name1);
            int num1 = 10;
            int num2;
            Console.WriteLine("enter the value: for num2");
            string value = Console.ReadLine();
            /*  num2 =int.Parse(value);  //parsing method
             Console.WriteLine("Num2: "+num2);*/
            num2=Convert.ToInt32(value);
            Console.WriteLine("Num2:(using Convert is a class"+num2);

            #endregion
        }
    }
}
