﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ConsoleApp1
{
    
    public class Course
    {
        public int CourseId { get; set; }      // Primary Key
        public string CourseName { get; set; }


        // Foreign Key
        [ForeignKey("studentId")]
        public int StudentId { get; set; }

        // Navigation Property
        public Student Student { get; set; }
    }

}
