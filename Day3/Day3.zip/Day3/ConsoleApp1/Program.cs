﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var context = new StudentContext();
            
                // Ensure database is created
                context.Database.EnsureCreated();

                // ---------------- Create Student ----------------
                var student1 = new Student
                {
                    Name = "Rahul Sharma",
                   
                    Age = 21
                };
                context.Students.Add(student1);
                context.SaveChanges();
                Console.WriteLine("Student Added.");

                // ---------------- Create Course ----------------
                var course1 = new Course
                {
                    CourseName = "C# Basics",
                    
                    StudentId = student1.StudentId  // Assign to Rahul
                };
                context.Courses.Add(course1);
                context.SaveChanges();
                Console.WriteLine("Course Added.");

                // ---------------- Read Students ----------------
                var students = context.Students.Include(s => s.Courses).ToList();
                Console.WriteLine("\n--- Students & Their Courses ---");
                foreach (var s in students)
                {
                    Console.WriteLine($"Student: {s.StudentId} - {s.Name}");
                    foreach (var c in s.Courses)
                    {
                        Console.WriteLine($"    Course: {c.CourseName}");
                    }
                }

                // ---------------- Update Student ----------------
                var studentToUpdate = context.Students.Find(student1.StudentId);
                if (studentToUpdate != null)
                {
                    studentToUpdate.Name = "Rahul K. Sharma";
                    context.SaveChanges();
                    Console.WriteLine("\nStudent Updated.");
                }

                // ---------------- Delete Course ----------------
                var courseToDelete = context.Courses.Find(course1.CourseId);
                if (courseToDelete != null)
                {
                    context.Courses.Remove(courseToDelete);
                    context.SaveChanges();
                    Console.WriteLine("Course Deleted.");
                }

                // ---------------- Final List ----------------
                var finalStudents = context.Students.Include(s => s.Courses).ToList();
                Console.WriteLine("\n--- Final Students & Courses ---");
                foreach (var s in finalStudents)
                {
                    Console.WriteLine($"Student: {s.StudentId} - {s.Name}");
                    foreach (var c in s.Courses)
                    {
                        Console.WriteLine($"    Course: {c.CourseName}");
                    }
                }
            }
    }



}
