﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ConsoleApp1
{

    [Table("Student2")]
    public class Student
    {
        public int StudentId { get; set; }     // Primary Key
        public string Name { get; set; }
        [Column("sid")]
        public int Age { get; set; }

        // Navigation Property (One-to-Many: One Student → Many Courses)
        //public ICollection<Course> Courses { get; set; }
        public List<Course> Courses { get; set; }
    }


}
