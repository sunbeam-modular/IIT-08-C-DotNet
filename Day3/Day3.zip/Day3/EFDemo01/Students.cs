﻿using System.ComponentModel.DataAnnotations;

namespace EFDemo01
{
    class Students
    {
        [Key]
        public int RollNo { get; set; }
        public string Name { get; set; }
    }
}
