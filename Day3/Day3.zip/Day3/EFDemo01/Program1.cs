﻿namespace EFDemo01
{
    internal class Program1
    {

        static SbContext sb = new SbContext();
        static void Main(string[] args)
        {

           
        }

        public static void  GetAllStudents()
        {
            var result = from s in sb.Students
                         select s;
            foreach (var item in result)
            {
                Console.WriteLine($"{item.RollNo} Name:{item.Name}");
            }
        }

        public static int Add()
        {
            Students s = new Students
            {
                Name = "Mira"
            };
            sb.Students.Add(s);
            return sb.SaveChanges();
        }

        public static void FindStudents(int id)
        {
            // return sb.Students.Find(1);
            var result = (from s in sb.Students
                          where s.RollNo == id
                          select s).First();

           
        }

        public static int Update()
        {
            Students s = sb.Students.Find(1);
            s.Name = "gita";
            //sb.Students.Add(s);
            return sb.SaveChanges();

        }
        public static int Delete()
        {
            Students s = sb.Students.Find(1);
            sb.Students.Remove(s);
            return sb.SaveChanges();

        }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDemo01
{
    internal class Program1
    {
    }
}
