﻿using System.ComponentModel.DataAnnotations;

namespace EFDemo01
{
    class Courses
    {
        [Key]
        public int CourseId { get; set; }
        public string Name { get; set; }
    }
}
