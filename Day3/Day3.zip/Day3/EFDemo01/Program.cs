﻿namespace EFDemo01
{
    internal class Program
    {

        static SbContext sb = new SbContext();
        static void Main(string[] args)
        {

            List<Students> studlist=GetAllStudents();

            foreach (var item in studlist)
            {
                Console.WriteLine($"RollNo:{item.RollNo} Name:{item.Name}");
            }

            // Console.WriteLine("Row Affected: "+Add());
            // 
           Students s= FindStudents();
            Console.WriteLine($"Found:{s.RollNo} Name:{s.Name}");
            Console.WriteLine("Row Affected: " + Update());



            //select * from students

        }

        public static  List<Students> GetAllStudents()
        {
            return sb.Students.ToList();
        }

        public static int Add()
        {
            Students s = new Students
            {
                Name = "Mira"
            };
            sb.Students.Add(s);
           return  sb.SaveChanges();
        }

        public static Students FindStudents()
        {
         // return sb.Students.Find(1);
         Students s= sb.Students.Find(1);
            return s;
        }

        public static int Update()
        {
            Students s = sb.Students.Find(1);
            s.Name = "gita";
            //sb.Students.Add(s);
            return sb.SaveChanges();

        }
        public static int Update()
        {
            Students s = sb.Students.Find(1);
            sb.Students.Remove(s);
            return sb.SaveChanges();

        }
    }
}
