﻿using Microsoft.EntityFrameworkCore;

namespace EFDemo01
{
    class SbContext :DbContext
    {
        public DbSet<Students> Students { get; set; }
        public DbSet<Courses> Courses { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(LocalDB)\\MSSQLLocalDB;Database=StudentDB1;Trusted_Connection=True;");
        }
    }
}
